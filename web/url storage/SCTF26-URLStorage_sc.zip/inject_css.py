import os
import glob

css = """
    <style>
        :root {
            --bg-color: #0f172a;
            --glass-bg: rgba(255, 255, 255, 0.05);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --accent: #3b82f6;
            --accent-hover: #2563eb;
        }
        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            background-image: 
                radial-gradient(at 0% 0%, rgba(59, 130, 246, 0.15) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(139, 92, 246, 0.15) 0px, transparent 50%);
        }
        .container, form, .glass-panel {
            background: var(--glass-bg);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 2rem;
            margin: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        h1, h3 {
            margin-top: 0;
            color: #fff;
        }
        input {
            width: 90%;
            padding: 0.75rem;
            margin-bottom: 1rem;
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid var(--glass-border);
            border-radius: 8px;
            color: #fff;
            outline: none;
            transition: border-color 0.2s;
        }
        input:focus {
            border-color: var(--accent);
        }
        button {
            width: 100%;
            padding: 0.75rem;
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        button:hover {
            background: var(--accent-hover);
        }
        a {
            color: var(--accent);
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        hr {
            border: 0;
            height: 1px;
            background: var(--glass-border);
            margin: 2rem 0;
        }
        code {
            background: rgba(0,0,0,0.3);
            padding: 0.2rem 0.4rem;
            border-radius: 4px;
            color: #38bdf8;
        }
    </style>
"""

def wrap_content(filepath):
    with open(filepath, 'r') as f:
        content = f.read()
    
    if '<style>' in content:
        return
        
    content = content.replace('</head>', css + '</head>')
    content = content.replace('<body>', '<body>\n    <div class="glass-panel">')
    content = content.replace('</body>', '    </div>\n</body>')
    
    with open(filepath, 'w') as f:
        f.write(content)

for html_file in glob.glob(r'c:\Users\jonxa\Downloads\SOAL SCTF26\SCTF26-URLStorage\web\templates\*.html'):
    wrap_content(html_file)
    print(f"Updated {html_file}")
